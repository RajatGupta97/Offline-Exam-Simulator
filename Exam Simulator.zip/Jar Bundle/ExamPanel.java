import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class ExamPanel extends JPanel implements ActionListener
{
	//===========================================================
	int max = 10;
	int qus_ids [] = new int[10];
	
	int current_qus = 0;
	
	Question questions[] = new Question[10];
	//============================================================
	JLabel lbl_welcome;
	JRadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7,rb8,rb9,rb10;
	ButtonGroup bg, bg_opt;
	
	JLabel lbl_ques;
	
	JTextArea txt_qus;
	
	JRadioButton opt1, opt2, opt3, opt4;
	
	JButton prev, next, finish;
	
	public ExamPanel()
	{
		setLayout(null);
		
		//********* Top Label  **********************************************************
		lbl_welcome = new JLabel("<html><u>Exam Suite</u></html>");
		lbl_welcome.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 25));
		lbl_welcome.setForeground(Color.white);
		lbl_welcome.setBounds(450,30,500,60);
		add(lbl_welcome);
		
		//******** Separator Label *******************************************************
		JLabel lbl = new JLabel("  ");
		lbl.setOpaque(true);
		lbl.setBackground(Color.white);
		lbl.setBounds(270,100,3,400);
		add(lbl);	
			
		rb1 = new JRadioButton("Question - 1");
		rb2 = new JRadioButton("Question - 2");
		rb3 = new JRadioButton("Question - 3");
		rb4 = new JRadioButton("Question - 4");
		rb5 = new JRadioButton("Question - 5");
		rb6 = new JRadioButton("Question - 6");
		rb7 = new JRadioButton("Question - 7");
		rb8 = new JRadioButton("Question - 8");
		rb9 = new JRadioButton("Question - 9");
		rb10 = new JRadioButton("Question - 10");
		
		bg = new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		bg.add(rb4);
		bg.add(rb5);
		bg.add(rb6);
		bg.add(rb7);
		bg.add(rb8);
		bg.add(rb9);
		bg.add(rb10);
		
		rb1.setBounds(60, 100, 150, 30); rb1.setOpaque(false); rb1.setForeground(Color.white) ; rb1.setFont(new Font("Arial", Font.BOLD, 18)); add(rb1);
		rb2.setBounds(60, 130, 150, 30); rb2.setOpaque(false); rb2.setForeground(Color.white) ; rb2.setFont(new Font("Arial", Font.BOLD, 18)); add(rb2);
		rb3.setBounds(60, 160, 150, 30); rb3.setOpaque(false); rb3.setForeground(Color.white) ; rb3.setFont(new Font("Arial", Font.BOLD, 18)); add(rb3);
		rb4.setBounds(60, 190, 150, 30); rb4.setOpaque(false); rb4.setForeground(Color.white) ; rb4.setFont(new Font("Arial", Font.BOLD, 18)); add(rb4);
		rb5.setBounds(60, 220, 150, 30); rb5.setOpaque(false); rb5.setForeground(Color.white) ; rb5.setFont(new Font("Arial", Font.BOLD, 18)); add(rb5);
		rb6.setBounds(60, 250, 150, 30); rb6.setOpaque(false); rb6.setForeground(Color.white) ; rb6.setFont(new Font("Arial", Font.BOLD, 18)); add(rb6);
		rb7.setBounds(60, 280, 150, 30); rb7.setOpaque(false); rb7.setForeground(Color.white) ; rb7.setFont(new Font("Arial", Font.BOLD, 18)); add(rb7);
		rb8.setBounds(60, 310, 150, 30); rb8.setOpaque(false); rb8.setForeground(Color.white) ; rb8.setFont(new Font("Arial", Font.BOLD, 18)); add(rb8);
		rb9.setBounds(60, 340, 150, 30); rb9.setOpaque(false); rb9.setForeground(Color.white) ; rb9.setFont(new Font("Arial", Font.BOLD, 18)); add(rb9);
		rb10.setBounds(60, 370, 150, 30); rb10.setOpaque(false); rb10.setForeground(Color.white) ; rb10.setFont(new Font("Arial", Font.BOLD, 18)); add(rb10);
		
		rb1.setActionCommand("1");
		rb2.setActionCommand("2");
		rb3.setActionCommand("3");
		rb4.setActionCommand("4");
		rb5.setActionCommand("5");
		rb6.setActionCommand("6");
		rb7.setActionCommand("7");
		rb8.setActionCommand("8");
		rb9.setActionCommand("9");
		rb10.setActionCommand("10");
		
		rb1.addActionListener(this);
		rb2.addActionListener(this);
		rb3.addActionListener(this);
		rb4.addActionListener(this);
		rb5.addActionListener(this);
		rb6.addActionListener(this);
		rb7.addActionListener(this);
		rb8.addActionListener(this);
		rb9.addActionListener(this);
		rb10.addActionListener(this);
		
		lbl_ques = new JLabel("Question : ");
		lbl_ques.setOpaque(false);
		lbl_ques.setFont(new Font("Arial", Font.BOLD, 18));
		lbl_ques.setForeground(Color.white);
		lbl_ques.setBounds(300,100,150,30);
		add(lbl_ques);
		
		txt_qus = new JTextArea();
		txt_qus.setFont(new Font("Arial", Font.PLAIN, 18));
		txt_qus.setOpaque(false);
		txt_qus.setEditable(false);
		
		JScrollPane sp = new JScrollPane(txt_qus);
		sp.setOpaque(false);
		sp.setBounds(300, 140, 600, 80);
		add(sp);
		
		opt1 = new JRadioButton("Option");	
		opt2 = new JRadioButton("Option");	
		opt3 = new JRadioButton("Option");	
		opt4 = new JRadioButton("Option");	
		
		opt1.setBounds(350, 240, 550, 30); opt1.setOpaque(false); opt1.setForeground(Color.white) ; opt1.setFont(new Font("Arial", Font.BOLD, 18)); add(opt1);
		opt2.setBounds(350, 280, 550, 30); opt2.setOpaque(false); opt2.setForeground(Color.white) ; opt2.setFont(new Font("Arial", Font.BOLD, 18)); add(opt2);
		opt3.setBounds(350, 320, 550, 30); opt3.setOpaque(false); opt3.setForeground(Color.white) ; opt3.setFont(new Font("Arial", Font.BOLD, 18)); add(opt3);
		opt4.setBounds(350, 360, 550, 30); opt4.setOpaque(false); opt4.setForeground(Color.white) ; opt4.setFont(new Font("Arial", Font.BOLD, 18)); add(opt4);
		
		bg_opt = new ButtonGroup();
		bg_opt.add(opt1);
		bg_opt.add(opt2);
		bg_opt.add(opt3);
		bg_opt.add(opt4);
		
		prev = new JButton("", new ImageIcon("prev.png"));
		prev.setBounds(350,420, 200, 40);
		prev.setFont(new Font("Arial", Font.BOLD, 15));
		prev.setToolTipText("Go to previous question");
		prev.addActionListener(this);
		add(prev);
		
		next = new JButton("", new ImageIcon("next.png"));
		next.setBounds(570,420, 200, 40);
		next.setFont(new Font("Arial", Font.BOLD, 15));
		next.setToolTipText("Go to next question");
		next.addActionListener(this);
		add(next);
		
		finish = new JButton("", new ImageIcon("finish.png"));
		finish.setBounds(100,420, 40, 40);
		finish.setFont(new Font("Arial", Font.BOLD, 15));
		finish.setToolTipText("Finish the Exam");
		finish.addActionListener(this);
		add(finish);
		
		generateRandom();
		
		getQuestions();
		
		current_qus = 1;
		displayQuesstion(current_qus);
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == next){
			saveAnswer(current_qus);
			if(current_qus == questions.length)
			{
				JOptionPane.showMessageDialog(this, "You are on last question");
				return;
			}
			current_qus++;
			displayQuesstion(current_qus);
		}
		else if(e.getSource() == prev){
			saveAnswer(current_qus);
			if(current_qus == 1)
			{
				JOptionPane.showMessageDialog(this, "You are on first question");
				return;
			}
			current_qus--;
			displayQuesstion(current_qus);
		}
		else if(e.getSource() == rb1 || e.getSource() == rb2 || e.getSource() == rb3 || e.getSource() == rb4 ||
				e.getSource() == rb5 || e.getSource() == rb6 || e.getSource() == rb7 || e.getSource() == rb8 ||
				e.getSource() == rb9 || e.getSource() == rb10
			){
				
			saveAnswer(current_qus);
			current_qus = Integer.parseInt(e.getActionCommand());
			System.out.println("Radio"+ current_qus);
			displayQuesstion(current_qus);			
			 
		}
		else if(e.getSource() == finish){
			saveAnswer(current_qus);
			calculateScore();
		}
	}
	
	public void calculateScore(){
		int score = 0;
		for(int i = 0; i < questions.length; i++){
			if(questions[i].answer.equals(questions[i].userAnswer)){
				score++;
			}
		}
		int per = (score*100)/questions.length;
		
		try{
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		    Connection con = DriverManager.getConnection(MainFrame.url,MainFrame.user, MainFrame.password);
			Statement stmt = con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select max(id) from STUDENT_DETAILS");
			rs.next();
			String id = rs.getString(1);
						
			String sql = "update student_details set score="+per+" where id = "+id;
			
			stmt.execute(sql);
			
			stmt.close();
			con.close();
		}
		catch(Exception exx){
			exx.printStackTrace();	
		}
		
		JOptionPane.showMessageDialog(this, "Your score is " + per + "%");
		StartPanel.card_layout.show(StartPanel.card_panel, "AdminLoginPanel");
		
		MainFrame.cardLayout.show(MainFrame.mf.getContentPane(), "Start");
	}
	
	public void saveAnswer(int question){
		int index = question-1;
		String ans = "";
		if(opt1.isSelected()) ans = "1";
		else if(opt2.isSelected()) ans = "2";
		else if(opt3.isSelected()) ans = "3";
		else if(opt4.isSelected()) ans = "4";
		
		questions[index].userAnswer =  ans;
	}
	
	public void displayQuesstion(int question){
		int index = question-1;
		txt_qus.setText(questions[index].question);
		opt1.setText(questions[index].optionA);
		opt2.setText(questions[index].optionB);
		opt3.setText(questions[index].optionC);
		opt4.setText(questions[index].optionD);
		
		bg_opt.clearSelection();
		
		if(questions[index].userAnswer != null && !questions[index].userAnswer.equals(""))
		{
			int user_ans = Integer.parseInt(questions[index].userAnswer);
			switch(user_ans){
				case 1: opt1.setSelected(true);break;
				case 2: opt2.setSelected(true);break;
				case 3: opt3.setSelected(true);break;
				case 4: opt4.setSelected(true);break;
			}
		}
		
		switch(question){
			case 1: rb1.setSelected(true); break;
			case 2: rb2.setSelected(true); break;
			case 3: rb3.setSelected(true); break;
			case 4: rb4.setSelected(true); break;
			case 5: rb5.setSelected(true); break;
			case 6: rb6.setSelected(true); break;
			case 7: rb7.setSelected(true); break;
			case 8: rb8.setSelected(true); break;
			case 9: rb9.setSelected(true); break;
			case 10: rb10.setSelected(true); break;
		}
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Image i = Toolkit.getDefaultToolkit().getImage("frame_bg.jpg");
		g.drawImage(i, 0,0,getWidth(),getHeight(), this);
		
		
	}
	
	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
	
	public void generateRandom(){
		for(int i = 0; i < qus_ids.length ;){
			int no = (int)Math.ceil(Math.random() * max);
			
			boolean found = false;
			for(int j = 0 ; j < i; j++){
				if(qus_ids[j] == no){
					found = true;
					break;
				}
			}
			
			if(found){
				continue;
			}	
			else{
				qus_ids[i] = no;
				i++;
			}
		}
		
		System.out.println("Generated Random Nos : ");
		for(int i = 0 ; i < qus_ids.length; i++){
			System.out.print(qus_ids[i] + ", ");
		}
	}
	
	public void getQuestions(){
		try{
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		    Connection con = DriverManager.getConnection(MainFrame.url,MainFrame.user, MainFrame.password);
			Statement stmt = con.createStatement();
			
			String qus_ids_str = "";
			for(int i=0; i<qus_ids.length; i++){
				if(i != 0)
					qus_ids_str += ",";
					
				qus_ids_str += qus_ids[i];
			}
			
			String sql = "select * from questions where qid in ("+qus_ids_str+")";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int ind = 0;
			while(rs.next()){
				Question qus = new Question();
				qus.question = rs.getString("QTEXT");
				qus.optionA = rs.getString("OPTION1");
				qus.optionB = rs.getString("OPTION2");
				qus.optionC = rs.getString("OPTION3");
				qus.optionD = rs.getString("OPTION4");
				qus.answer = rs.getString("ANSWER");
				
				questions[ind++] = qus;
			}
			
			rs.close();
			stmt.close();
			con.close();
		}
		catch(Exception e){
			
		}
	}
}