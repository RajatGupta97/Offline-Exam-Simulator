import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class StudentRegisterPanel extends JPanel implements ActionListener
{
	JTextField t1,t2,t3,t4,t5,t6;
	JButton b_Submit,b_Cancel;
	JLabel lb1,lb2,lb3,lb4,lb5,lb6;
				
	public StudentRegisterPanel()
	{
			
		setLayout(null);
		setOpaque(false);
		lb1 = new JLabel("<html><b>STUDENT's NAME</b></html>");
		lb1.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb1.setForeground(Color.WHITE);
		lb2 = new JLabel("<html><b>FATHER'S NAME</b></html>");
		lb2.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb2.setForeground(Color.WHITE);
		lb3 = new JLabel("<html><b>MOBILE NUMBER</b></html>");
		lb3.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb3.setForeground(Color.WHITE);
		lb4 = new JLabel("<html><b>AGE</b></html>");
		lb4.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb4.setForeground(Color.WHITE);
		lb5 = new JLabel("<html><b>ADDRESS</b></html>");
		lb5.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb5.setForeground(Color.WHITE);
		lb6 = new JLabel("<html><b>COURSE</b></html>");
		lb6.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 17));
		lb6.setForeground(Color.WHITE);
		lb1.setHorizontalAlignment(JLabel.CENTER);
		lb2.setHorizontalAlignment(JLabel.CENTER);
		lb3.setHorizontalAlignment(JLabel.CENTER);
		lb4.setHorizontalAlignment(JLabel.CENTER);
		lb5.setHorizontalAlignment(JLabel.CENTER);
		lb6.setHorizontalAlignment(JLabel.CENTER);
		b_Submit = new JButton("<html><b>SUBMIT</b></html>");
		b_Submit.setHorizontalAlignment(JButton.CENTER);
		b_Submit.addActionListener(this);
		b_Cancel = new JButton("<html><b>CANCEL</b></html>");
		b_Cancel.setHorizontalAlignment(JButton.CENTER);
		b_Cancel.addActionListener(this);
		t1=new JTextField(50);
		t1.setFont(new Font("Arial", Font.BOLD , 16));
		t2=new JTextField(50);
		t2.setFont(new Font("Arial", Font.BOLD , 16));
		t3=new JTextField(50);
		t3.setFont(new Font("Arial", Font.BOLD , 16));
		t4=new JTextField(50);
		t4.setFont(new Font("Arial", Font.BOLD , 16));
		t5=new JTextField(50);
		t5.setFont(new Font("Arial", Font.BOLD , 16));
		t6=new JTextField(50);
		t6.setFont(new Font("Arial", Font.BOLD , 16));
		lb1.setBounds(15,10,200,40);
		lb2.setBounds(15,60,200,40);
		lb3.setBounds(15,110,200,40);
		lb4.setBounds(15,160,200,40);
		lb5.setBounds(15,210,200,40);
		lb6.setBounds(15,260,200,40);
		t1.setBounds(250,10,200,40);
		t2.setBounds(250,60,200,40);
		t3.setBounds(250,110,200,40);
		t4.setBounds(250,160,200,40);
		t5.setBounds(250,210,200,40);
		t6.setBounds(250,260,200,40);
		b_Submit.setBounds(150,330,100,30);
		b_Cancel.setBounds(310,330,100,30);
		add(lb1);
		add(lb2);
		add(lb3);
		add(lb4);
		add(lb5);
		add(lb6);
		add(t1);
		add(t2);
		add(t3);
		add(t4);
		add(t5);
		add(t6);
		add(b_Submit);
		add(b_Cancel);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		Object e=ae.getSource();
		if(e==b_Submit)
		{
			if(t1.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter name", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(t2.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter father's name", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(t3.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter mobile number", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(t4.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter age", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			else{
				try{
					Integer.parseInt(t4.getText());
				}
				catch(Exception ee){
					JOptionPane.showMessageDialog(this,"Please enter valid age", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			if(t5.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter address", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(t6.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please enter course", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			try{
				
				DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			    Connection con = DriverManager.getConnection(MainFrame.url,MainFrame.user, MainFrame.password);
				Statement stmt = con.createStatement();
				String sql= "insert into student_details (STUDENT_NAME,FATHERS_NAME,MOBILE_NUMBER,AGE,ADDRESS,COURSE) values ('"+t1.getText()+"','"+t2.getText()+"','"+t3.getText()+"','"+t4.getText()+"','"+t5.getText()+"','"+t6.getText()+"')";
				stmt.execute(sql);
				stmt.close();
				con.close();
				
				JOptionPane.showMessageDialog(this,"Registration Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
				
				InstructionsPanel ip = new InstructionsPanel();
				StartPanel.card_panel.add("InstructionsPanel", ip);
				StartPanel.card_layout.show(StartPanel.card_panel, "InstructionsPanel");
				
				MainFrame.student_name = t1.getText();
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
			}
			catch(SQLException ex){
				JOptionPane.showMessageDialog(this,"Registration Failed" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace();
			}
		}
		else if(e==b_Cancel)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
		}
	}

		
	public static void main(String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}