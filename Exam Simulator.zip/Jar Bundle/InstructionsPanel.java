import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InstructionsPanel extends JPanel implements ActionListener
{
	JButton btn1;
	JTextArea jtru;
	String em;

	public InstructionsPanel()		
{
	setLayout(null);
	setOpaque(false);

	String str="\n\t                EXAM RULES\n\n"+
	" This is  a simple user friendly software developed using Java. "+
	" It can be applied to schools ,colleges etc to conduct exams. "+
	" The procedure for using this software is very easy. "+
	"The questions "+
	"and options are displayed on the screen. We can choose one "+
	"of the answer.After completing the exam the results are"+
	"displayed on the screen.\n";

	jtru=new JTextArea(str,6,12);
	jtru.setEditable(false);
	jtru.setDisabledTextColor(Color.white);
	jtru.setWrapStyleWord(true);
	jtru.setLineWrap(true);
	jtru.setOpaque(false);
	jtru.setFont(new Font("Arial",Font.PLAIN,18));
	btn1=new JButton("START EXAM");
	btn1.addActionListener(this);
	jtru.setBounds(0,0,600,300);
	btn1.setBounds(450,310,100,30);
	add(btn1);
	add(jtru);
}
public void actionPerformed(ActionEvent ae)
{
	Object e=ae.getSource();
	if(e==btn1)
	{
		ExamPanel ep = new ExamPanel();
		MainFrame.mf.add(ep, "ExamPanel");
		MainFrame.cardLayout.show(MainFrame.mf.getContentPane(), "ExamPanel");
	}
}
public static void main(String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}