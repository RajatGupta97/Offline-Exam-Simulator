import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class AdminLoginPanel extends JPanel implements ActionListener
{
	JLabel lbl_welcome;
	JLabel lbl_user,lbl_pass,lbl_select;
	JTextField txt_user; 
	JPasswordField txt_pass;
	JButton b_submit,b_cancel;
	JRadioButton rb1,rb2;
	ButtonGroup bg;
				
	public AdminLoginPanel()
	{
		setLayout(null);
		setOpaque(false);
		lbl_welcome = new JLabel("<html><i><u>ADMIN LOGIN</u></i></html>");
		lbl_welcome.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 25));
		lbl_welcome.setHorizontalAlignment(JLabel.CENTER);
		lbl_welcome.setBounds(100,10,400,30);
		lbl_welcome.setForeground(Color.white);
		add(lbl_welcome);
		lbl_user=new JLabel("<html><b>USER NAME<b></html");
		lbl_pass=new JLabel("<html><b>PASSWORD<b></html");
		lbl_user.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 16));
		lbl_pass.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 16));
		lbl_user.setForeground(Color.WHITE);
		lbl_pass.setForeground(Color.WHITE);
		lbl_user.setBounds(30,100,100,35);
		lbl_pass.setBounds(30,160,100,35);
		txt_user=new JTextField(50);
		txt_user.setFont(new Font("Arial", Font.BOLD ,16));
		txt_user.setBounds(180,100,150,35);
		txt_pass=new JPasswordField(50);
		txt_pass.setFont(new Font("Arial", Font.BOLD ,16));
		txt_pass.setBounds(180,160,150,35);
		lbl_select=new JLabel("<html><b>ACTIVITY<b></html");
		lbl_select.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 16));
		lbl_select.setForeground(Color.WHITE);
		lbl_select.setBounds(30,220,100,35);
		rb1=new JRadioButton("<html><b>Add Question's in the Database</b></html>");
		rb2=new JRadioButton("<html><b>Score Report</b></html>");
		rb1.setBounds(180,220,230,35);
		rb2.setBounds(180,260,150,35);
		rb1.setForeground(Color.white);
		rb2.setForeground(Color.white);
		rb1.setOpaque(false);
		rb2.setOpaque(false);
		//rb1.addActionListener(this);
		//rb2.addActionListener(this);
		b_cancel=new JButton("<html><b>CANCEL</b></html>");
		b_cancel.setHorizontalAlignment(JButton.CENTER);
		b_cancel.setBounds(250,340,80,35);
		b_cancel.addActionListener(this);
		b_submit=new JButton("<html><b>SUBMIT</b></html>");
		b_submit.setHorizontalAlignment(JButton.CENTER);
		b_submit.setBounds(120,340,80,35);
		b_submit.addActionListener(this);
		bg=new ButtonGroup();	
		bg.add(rb1);
		bg.add(rb2);
		add(rb1);
		add(rb2);
		add(b_cancel);
		add(b_submit);
		add(lbl_user);
		add(lbl_pass);
		add(txt_pass);
		add(txt_user);
		add(lbl_select);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		Object e=ae.getSource();
		if(e == b_submit){
			if(txt_user.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please fill user name", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			if(txt_pass.getText().trim().length() == 0){
				JOptionPane.showMessageDialog(this,"Please fill password", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			if(!rb1.isSelected() && !rb2.isSelected()){
				JOptionPane.showMessageDialog(this,"Please select Activity", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			if(!txt_user.getText().equals("admin") && !txt_pass.getText().equals("admin"))
			{
				JOptionPane.showMessageDialog(this,"Username or Password is incorrect.", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			if(e==b_submit && rb1.isSelected())
			{
				DatabasePanel dp = new DatabasePanel();
				StartPanel.card_panel.add("DatabasePanel", dp);
				StartPanel.card_layout.show(StartPanel.card_panel, "DatabasePanel");
			}
			else if(e==b_submit && rb2.isSelected())
			{
				ScorePanel sp = new ScorePanel();
				StartPanel.card_panel.add("Score", sp);
				StartPanel.card_layout.show(StartPanel.card_panel, "Score");
			}
		}
		else if(e == b_cancel){
			txt_pass.setText("");
			txt_user.setText("");
			bg.clearSelection();
		}
	}

	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}