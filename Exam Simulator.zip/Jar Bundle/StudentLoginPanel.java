import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class StudentLoginPanel extends JPanel
{
	JLabel lbl_welcome;
	
				
	public StudentLoginPanel()
	{
		setLayout(null);
		setOpaque(false);
		lbl_welcome = new JLabel("<html><i>Student Login</i></html>");
		lbl_welcome.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 25));
		lbl_welcome.setHorizontalAlignment(JLabel.CENTER);
		lbl_welcome.setBounds(100,10,400,30);
		lbl_welcome.setForeground(Color.white);
		add(lbl_welcome);
	}
	
	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}