public class Question
{
	public String 	question,
					optionA,
					optionB,
					optionC,
					optionD,
					answer,
					userAnswer="";
}