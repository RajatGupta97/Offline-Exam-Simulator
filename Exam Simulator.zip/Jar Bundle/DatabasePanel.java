import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DatabasePanel extends JPanel implements ActionListener
{
	JLabel lbl_q,lbl_o1,lbl_o2,lbl_o3,lbl_o4,lbl_a;
	JTextArea t_q;
	JTextField t_o1,t_o2,t_o3,t_o4,t_a;
	JButton b_submit,b_cancel;
	JRadioButton r1,r2,r3,r4;
	ButtonGroup bg;
	
	public DatabasePanel()
	{
		setLayout(null);
		setOpaque(false);
		lbl_q=new JLabel("<html><b>Question</b></html>");
		lbl_q.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_q.setForeground(Color.WHITE);
		lbl_q.setHorizontalAlignment(JLabel.CENTER);
		lbl_o1=new JLabel("<html><b>Option 1</b></html>");
		lbl_o1.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_o1.setForeground(Color.WHITE);
		lbl_o1.setHorizontalAlignment(JLabel.CENTER);
		lbl_o2=new JLabel("<html><b>Option 2</b></html>");
		lbl_o2.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_o2.setForeground(Color.WHITE);
		lbl_o2.setHorizontalAlignment(JLabel.CENTER);
		lbl_o3=new JLabel("<html><b>Option 3</b></html>");
		lbl_o3.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_o3.setForeground(Color.WHITE);
		lbl_o3.setHorizontalAlignment(JLabel.CENTER);
		lbl_o4=new JLabel("<html><b>Option 4</b></html>");
		lbl_o4.setForeground(Color.WHITE);
		lbl_o4.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_o4.setHorizontalAlignment(JLabel.CENTER);
		lbl_a=new JLabel("<html><b>Answer</b></html>");
		lbl_a.setFont(new Font("Arial", Font.BOLD, 14));
		lbl_a.setForeground(Color.WHITE);
		lbl_a.setHorizontalAlignment(JLabel.CENTER);
		
		t_q=new JTextArea();
		t_q.setFont(new Font("Arial", Font.BOLD ,16));
		JScrollPane sp = new JScrollPane(t_q);
		t_o1=new JTextField(100);
		t_o1.setFont(new Font("Arial", Font.BOLD ,16));
		t_o2=new JTextField(100);
		t_o2.setFont(new Font("Arial", Font.BOLD ,16));
		t_o3=new JTextField(100);
		t_o3.setFont(new Font("Arial", Font.BOLD ,16));
		t_o4=new JTextField(100);
		t_o4.setFont(new Font("Arial", Font.BOLD ,16));
		t_a=new JTextField(100);
		t_a.setFont(new Font("Arial", Font.BOLD ,16));
		
		lbl_q.setBounds(0,10,100,25);
		sp.setBounds(120,10,400,50);
		
		lbl_o1.setBounds(0,80,100,25);
		t_o1.setBounds(120,80,400,25);
		
		lbl_o2.setBounds(0,130,100,25);
		t_o2.setBounds(120,130,400,25);
		
		lbl_o3.setBounds(0,180,100,25);
		t_o3.setBounds(120,180,400,25);
		
		lbl_o4.setBounds(0,230,100,25);
		t_o4.setBounds(120,230,400,25);
		
		lbl_a.setBounds(0,280,100,25);	
		//t_a.setBounds(120,280,400,25);
		
			
		r1 =  new JRadioButton("1");
		r2 =  new JRadioButton("2");
		r3 =  new JRadioButton("3");
		r4 =  new JRadioButton("4");
		
		bg = new ButtonGroup();
		bg.add(r1);		bg.add(r2);		bg.add(r3);		bg.add(r4);
		
		r1.setOpaque(false);
		r2.setOpaque(false);
		r3.setOpaque(false);
		r4.setOpaque(false);
		
		r1.setBounds(120,280,100,25);
		r2.setBounds(220,280,100,25);
		r3.setBounds(320,280,100,25);
		r4.setBounds(420,280,100,25);
		
		add(lbl_q);
		add(lbl_o1);
		add(lbl_o2);
		add(lbl_o3);
		add(lbl_o4);
		add(lbl_a);
		add(sp);
		add(t_o1);
		add(t_o2);
		add(t_o3);
		add(t_o4);
		add(r1);
		add(r2);
		add(r3);
		add(r4);
		b_submit=new JButton("<html><b>SUBMIT</b></html>");
		b_submit.setHorizontalAlignment(JButton.CENTER);
		b_submit.addActionListener(this);
		b_submit.setBounds(50,340,80,35);
		b_cancel=new JButton("<html><b>CANCEL</b></html>");
		b_cancel.setHorizontalAlignment(JButton.CENTER);
		b_cancel.addActionListener(this);
		b_cancel.setBounds(180,340,80,35);
		add(b_submit);
		add(b_cancel);
	}
public void actionPerformed(ActionEvent ae)
{
	Object e=ae.getSource();
	if(e==b_submit)
	{
		if(t_q.getText().trim().length() == 0){
			JOptionPane.showMessageDialog(this,"Please enter question", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(t_o1.getText().trim().length() == 0){
			JOptionPane.showMessageDialog(this,"Please enter option-1", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(t_o2.getText().trim().length() == 0){
			JOptionPane.showMessageDialog(this,"Please enter option-2", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(t_o3.getText().trim().length() == 0){
			JOptionPane.showMessageDialog(this,"Please enter option-3", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(t_o4.getText().trim().length() == 0){
			JOptionPane.showMessageDialog(this,"Please enter option-4", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		if(!r1.isSelected()&&!r2.isSelected()&&!r3.isSelected()&&!r4.isSelected()){
			JOptionPane.showMessageDialog(this,"Please select answer,", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		try{
				
				DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			    Connection con = DriverManager.getConnection(MainFrame.url,MainFrame.user, MainFrame.password);
				Statement stmt = con.createStatement();
				String ans = "";
				if(r1.isSelected()) ans = "1";
				else if(r2.isSelected()) ans = "2";
				else if(r3.isSelected()) ans = "3";
				else if(r4.isSelected()) ans = "4";
				
				String sql= "insert into questions(QTEXT,OPTION1, OPTION2, OPTION3, OPTION4,ANSWER) VALUES('"
										+t_q.getText()+"','"+t_o1.getText()+"','"+t_o2.getText()+"','"+t_o3.getText()+"','"
											+t_o4.getText()+"','"+ans+"')";
				stmt.execute(sql);
				stmt.close();
				con.close();
				
				JOptionPane.showMessageDialog(this,"Question added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
				t_q.setText("");
				t_o1.setText("");
				t_o2.setText("");
				t_o3.setText("");
				t_o4.setText("");
				bg.clearSelection();
				
			}
			catch(SQLException ex){
				JOptionPane.showMessageDialog(this,"Error : " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				ex.printStackTrace();
			}
	}
	else if(e==b_cancel)
	{
		t_q.setText("");
		t_o1.setText("");
		t_o2.setText("");
		t_o3.setText("");
		t_o4.setText("");
		bg.clearSelection();
		StartPanel.card_layout.show(StartPanel.card_panel, "AdminLoginPanel");
	}
}	
public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}