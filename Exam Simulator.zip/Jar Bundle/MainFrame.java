import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MainFrame extends JFrame
{
	public static String url = "jdbc:mysql://localhost:3306/examsuite";
	public static String user = "root";
	public static String password = "underground12";
	public static String student_name;
	
	public static CardLayout cardLayout;
	public static MainFrame mf;
	
	StartPanel startPanel;
	ExamPanel examPanel;
	public MainFrame()
	{
		cardLayout = new CardLayout();
		setUndecorated(true);// Hide Title bar
		setBounds(100,100,960,540);
		setResizable(false);
		setLayout(cardLayout);
		
		startPanel = new StartPanel();
		add("Start", startPanel);
		
		setVisible(true);	
		
		mf = this;
	}

	
	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}