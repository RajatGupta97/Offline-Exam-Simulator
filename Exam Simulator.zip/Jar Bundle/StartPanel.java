import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class StartPanel extends JPanel implements ActionListener
{
	JLabel lbl_welcome;
	
	JButton btn_admin_login,
			btn_student_register,
			btn_exit;
		
	public static JPanel card_panel;
	
	public static CardLayout card_layout;
			
	AdminLoginPanel admin_login_panel;
	StudentLoginPanel student_login_panel;
	StudentRegisterPanel student_register_panel;
	
	public StartPanel()
	{
		setLayout(null);
		
		//********* Top Label  **********************************************************
		lbl_welcome = new JLabel("<html><u>Welcome to Exam Suite Application</u></html>");
		lbl_welcome.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 25));
		lbl_welcome.setForeground(Color.white);
		lbl_welcome.setBounds(250,30,500,60);
		add(lbl_welcome);
		
		//********* Admin Login Button **************************************************
		btn_admin_login = new JButton("<html><b style='color:navy'>Admin Login<b></html>", new ImageIcon("key.png"));
		btn_admin_login.setBounds(50,100, 200,40);
		//btn_admin_login.setHorizontalAlignment(JButton.LEFT);
		btn_admin_login.addActionListener(this);
		add(btn_admin_login);
		
		//******** Student Register Button ***********************************************
		btn_student_register = new JButton("<html><b style='color:navy'>Student Registration<b></html>", new ImageIcon("add_user.png"));
		//btn_student_register.setHorizontalAlignment(JButton.LEFT);
		btn_student_register.setBounds(50,150, 200,40);
		btn_student_register.addActionListener(this);
		add(btn_student_register);
		
		//******** Student Register Button ***********************************************
		btn_exit = new JButton("", new ImageIcon("exit.png"));
		btn_exit.setBounds(50,420, 100,70);
		btn_exit.setContentAreaFilled(false);
		btn_exit.setBorderPainted(false);
		btn_exit.addActionListener(this);
		add(btn_exit);
		
		
		//******** Separator Label *******************************************************
		JLabel lbl = new JLabel("  ");
		lbl.setOpaque(true);
		lbl.setBackground(Color.white);
		lbl.setBounds(270,100,3,400);
		add(lbl);
		
		//******** Card Panel ***********************************************************
		card_panel = new JPanel();
		//card_panel.setBackground(Color.red);
		card_panel.setOpaque(false);
		card_panel.setBounds(300, 100, 600, 380);
	
		card_layout = new CardLayout();
		card_panel.setLayout(card_layout);
			
		admin_login_panel = new AdminLoginPanel();
		card_panel.add("AdminLoginPanel", admin_login_panel);
		
		/*student_login_panel = new StudentLoginPanel();
		card_panel.add("StudentLoginPanel", student_login_panel);
		*/
		student_register_panel = new StudentRegisterPanel();
		card_panel.add("StudentRegisterPanel", student_register_panel);
		
		add(card_panel);
		
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Image i = Toolkit.getDefaultToolkit().getImage("frame_bg.jpg");
		g.drawImage(i, 0,0,getWidth(),getHeight(), this);
		
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == btn_admin_login){
			card_layout.show(card_panel, "AdminLoginPanel");
		}
		else if(e.getSource() == btn_student_register){
			card_layout.show(card_panel, "StudentRegisterPanel");
		}
		else if(e.getSource() == btn_exit){
			System.exit(0);
		}
	}
	
	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}