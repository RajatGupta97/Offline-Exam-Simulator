import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.*;
import  java.sql.*;

public class ScorePanel extends JPanel
{
	JLabel lbl_welcome;
	DefaultTableModel model;
	JTable table;
	
	/* To make the table cell non editable we create our own class, 
	   by default cells of the table are editable */
	class MyDefaultTableModel extends DefaultTableModel {

	    MyDefaultTableModel(Object[][] data, Object[] columnNames) {
	    	
	    	super(data, columnNames);
	    }
	    
	    public boolean isCellEditable(int row, int column) {
	    	
	        return false;
	    }
	}
				
	public ScorePanel()
	{
		setLayout(null);
		setOpaque(false);
		lbl_welcome = new JLabel("<html><i>Score Board</i></html>");
		lbl_welcome.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 25));
		lbl_welcome.setHorizontalAlignment(JLabel.CENTER);
		lbl_welcome.setBounds(100,10,400,30);
		lbl_welcome.setForeground(Color.white);
		add(lbl_welcome);
		
						  
		String columns[] = {"Name", "Age", "Course", "Score"};
		model = new MyDefaultTableModel(new Object[0][0], columns);
		table = new JTable(model);
		
		try{
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		    Connection con = DriverManager.getConnection(MainFrame.url,MainFrame.user, MainFrame.password);
			Statement stmt = con.createStatement();
			
			String sql = "select * from student_details";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			int ind = 0;
			while(rs.next()){
				model.addRow(new String[]{rs.getString("STUDENT_NAME"), 
											rs.getString("AGE"),
											rs.getString("COURSE"),
											rs.getString("SCORE")+"%"});
			}
			
			rs.close();
			stmt.close();
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		JScrollPane pane = new JScrollPane(table);
		pane.setBounds(20, 50, 600,400);
		add(pane);
	}
	
	public static void main (String[] args) {
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}catch(Exception e){}
		new MainFrame();
	}
}